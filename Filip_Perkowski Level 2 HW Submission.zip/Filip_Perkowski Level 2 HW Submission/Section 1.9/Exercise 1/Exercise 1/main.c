#include <stdio.h>

//Objective- This C-program is designed to output on the console user input after every space;
//The termination key will be CTRL + A; (On my console it's CTRL + Shift + A); The key depends on the system your'e using as per the Thread


//I'll use a while loop(we don't know the number of iterations therefore a while loop is preferable to a for loop) to go through each character in the user input; As long as there's valid input we will input it onto the console

int main() {
	
	char current; //This variable represents the current character being iterated through user input via the while loop()
	
	printf("Enter any combination input. Once youre' done enter CTRL + A: ");

	current = getchar(); //getchar() gets a character from the keyboard/user input
	while (current != 1) { //1 is the ASCII value for CTRL + A
	    putchar(current); //Print this char out onto the console
		current = getchar(); //Move onto the next char
		
	}

	printf("CTRL + A is a correct ending"); //Once we terminate via the CTRL + SHIFT + A we print out this line
}