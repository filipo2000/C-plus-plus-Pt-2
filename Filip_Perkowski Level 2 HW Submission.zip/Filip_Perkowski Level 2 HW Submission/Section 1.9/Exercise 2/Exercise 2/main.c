#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <string.h>

//Objective- This program is the extension of the last Excercise except that now here we incorporate files: so we open a file as requested per user input and output the input via the user into the designated folder instead of to the output

//Making our File object;
FILE* one;

int main() {

	char str[100]; //This will hold the name of the file provided via user input; A string in C is a char array with 2 [] operators; Alternatively we could've made a const char* variable
	char current; //This will be the char variable which will iterate through the user input in the while loop


	//Now asking for user input
	printf("Please provide the name of the file in which you would like to put your input into: \n");
	scanf("%s", &str); //Variable str hold the name of the file via user input
	
    //Now let's open the file via the fopen() function
	one = fopen(str, "w");

	//Now we are asking for the user to input a combination
	printf("Please provide any input combination. End with a CTRL + A: ");
	
	//Now that we have user input on our keyboard we can execute the following while loop
	current = getchar(); //getchar() is a function which fetches characters from user input
	while (current != 1) {
		fputc(current, one); //This puts the respective character from user input into our file
		current = getchar(); //Variable now iterates to the next character in user input
	}

	fclose(one); //Once we are done we can close our file chosen via user input
}