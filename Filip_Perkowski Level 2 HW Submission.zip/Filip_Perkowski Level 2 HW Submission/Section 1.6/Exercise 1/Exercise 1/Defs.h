#pragma once
#include <stdio.h>

//Objective- This is our header file where I defined both macros: PRINT1 AND PRINT2 accordingly. Doing so I can freely now implement these Macros in the main() function simililarly to a function

//PRINT1 macro prints out the argument it's provided when it's called
//PRINT2 macro prints out both arguments onto the console when it's called

#ifndef Defs_h 
#define Defs_h //Starting our header file definition below

//These are our 2 Macros: PRINT1 and PRINT2
#define PRINT1(a)(printf("a equals: %d\n", a)) //PRINT1 definition
#define PRINT2(a,b)(printf("a equals: %d and b equals: %d", a, b)) //PRINT2 definition





#endif //Done with the contents of our header file