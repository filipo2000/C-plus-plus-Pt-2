#include <stdio.h>
#include "Defs.h"

//Objective- This is our source file which includes the main() function to effectively run both of our macros defined in Defs.h header file


int main() {

	//Variables which will hold both values via user input that we'd like to print out through our macros
	int first;
	int second;

	//Taking in user input
	printf("Please enter 2 values that you'd like to print out:\n");
	scanf_s("%d", &first);
	scanf_s("%d", &second);

	//Calling both of our Macros from the Defs.h file
	PRINT1(first);
	PRINT2(first, second);
}

//Preprocessor logic to prohibit multiple inclusion of the header file
#ifndef Defs_h
#include "Defs.h"
#endif