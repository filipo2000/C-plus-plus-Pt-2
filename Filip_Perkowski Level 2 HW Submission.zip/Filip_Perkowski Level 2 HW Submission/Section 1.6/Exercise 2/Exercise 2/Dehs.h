#pragma once

#include <stdio.h>

#ifndef Defs_h
#define Defs_h //Our header file Defs.h starts below


//Objective- This is the extended Defs.h header file. We have the definitions of: PRINT1 AND PRINT2 Macros from Exercise 1. In addition, to the MAX2 and MAX3 macros

//These are our 2 Macros: PRINT1 and PRINT2 from Exersise 1
#define PRINT1(a)(printf("a equals: %d\n", a))
#define PRINT2(a,b)(printf("a equals: %d and b equals: %d", a, b))

//Our 2 Macro definitions: MAX2 and MAX3 
#define MAX2(x1, x2)((x1 > x2)? x1 : x2) //2 arguments are taken; If x1(1st argument) is larger than the 2nd argument(x2) then return x1; Otherwise, return x2
#define MAX3(x1, x2, x3)((x3 > MAX2(x1, x2))? x3: MAX2(x1, x2)) //Here there's an additional part x3; So if x3 is larger than x1 && x2, then return x3; Otherwise initiate the MAX2 macro and return the greater number between x1 and x2





#endif //Our header file definition ends here