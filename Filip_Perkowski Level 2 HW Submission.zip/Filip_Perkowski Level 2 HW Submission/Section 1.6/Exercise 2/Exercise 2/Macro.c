#include <stdio.h>
#include "Dehs.h"


//Objective- This is our source file. Here we have our main() function in which we can freely test all the macros defined in the Defs.h header file as long as we've included it here via #include

//In our main function, we are testing the MAX2 and MAX3 Macro
int main() {
	
	int result1 = MAX2(7, 3);
	printf("%d\n", result1); //Outputs 7 as it should based on the above arguments

	int result2 = MAX3(5,14,8);
	printf("%d", result2); //Outputs 14 as it should based on the above arguments

}

//Preprocessor logic to avoid multiple inclusion of our Defs.h header file
#ifndef Defs_h
#include "Dehs.h"
#endif