
#include <stdio.h>

//Objective- This is our Swap function which will effectively swap the values of our inputs; I'll use a third party variable to assist with this action
//Our parameters will be pointers; We will derefrence them to acess the values provided via the function call

//This is our Swap function defined. The function takes in pointers as arguments to assist with the value swapping
//I made it a void function as I don't want it to return anything
void Swap(int* a, int* b) {
	int temp = *b; //Third part int variable temp is used to hold the b value. If we don't perform this action then we will swap the swap and we will ultimately end up with what we started with. a having it's original value as well as b
	*b = *a;
	*a = temp;
}


int main() {

	//Our 2 variables which will hold the 2 values that will be swapped from user input
	int first;
	int second;

	//User Input
	printf("Please enter a value for variable first: ");
	scanf_s("%d", &first);

	//User Input Contd.
	printf("Now please enter a variable for the variable second: ");
	scanf_s("%d", &second);

	//An alternative method for doing this problem would be to make 2 pointers. Set the pointers to variables first and second. Then use both pointers as arguments for the Swap() call. But that's involves more variables etc.
	
	//Pre-Swap
	printf("Values of first and second are: %d and %d\n", first, second);

	//Swapping
	Swap(&first, &second); // Arguments are adresses of variables since the functions parameters are pointers to a int; Now the pointers a and b in the Swap() function point to specific variables
	
	//Post-Swap
	printf("Post-swaping values of first and second are: %d and %d\n", first, second);
}