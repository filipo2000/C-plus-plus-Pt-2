
#include <stdio.h>

//Objective- In this exercise we will create a function named- DayName() which will be able to print any day of the week via the corresponding number (1-7)

const char* DayName(int i); //Function Decleration; So C knows that we have a function named DayName which returns a string; Or only other option would be to define and declare it at the same time; This is based on the fact that code is executed sequentially in main()

//Our array of strings hard coded which will hold days of the week; To achieve this we must use 2 subscripts
char days[8][10] = { "NULL", "Sunday", "Monday", "Tuesday", "Wensday", "Thursday", "Friday", "Saturday" }; //First subscript reffers to the number of elements in the array. 2nd aka inner subscript reffers to the maximum length of each element in the array(in this case 10 character max for each string element)
//I put a NULL string in the 0th index as a placeholder;

int main() {
	
	int num; //This is our variable which will hold a number 1 - 7;

	//User input
	printf("Please enter a number from 1 to 7: ");
	scanf_s("%d", &num);

	//Fetching the result
	printf("Day %d is a %s",num, DayName(num));
}

const char* DayName(int i) {

	return days[i]; //This is because we must account for the fact that indexes start at 0; I also could've asked the user to input a number 0-6; Both solutions work
}  //It's important to know that a variable defined within a local scope like a function. It won't be defined outside for this reason we wuold'nt be able to return the variable straightly. An option would be to set it's value equal to a global variable and return the global
   //If we wanted to return a specific character then we would use 2 [][] index symbols for our return variable alongiside the name of the array