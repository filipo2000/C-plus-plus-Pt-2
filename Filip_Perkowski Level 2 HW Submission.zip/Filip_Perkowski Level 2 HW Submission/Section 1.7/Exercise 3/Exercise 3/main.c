
/* Predict what will be printed on the screen */

//IMPORTANT: DOUBLE CHECK WHAT IT MEANS WHEN WE ARE COMPARING POINTERS LIKE THE FOLLOWING: SUPPOSE A AND B ARE POINTERS AND WE WRITE-
// A <= B; THIS EXPRESSION RESULTS TRUE AS LONG AS B POINTS AT THE SAME ELEMENT AS A OR IS FURTHER AWAY FROM THE STARTING ELEMENT THAN POINTER A IN A GIVEN ARRAY
//IS MY INTERPRETAION OF THE ABOVE CORRECT OR AM INCORRECT

#include <stdio.h>

//Objective- This program will comment the output as well as the reasoning for the output on each relevant line

#define PRD(a) printf("%d", (a) ) // PRD(Print Decimal) MACRO; This MACRO prints the decimal value that it's provided via argument when called in the program
#define NL printf("\n"); // Print new line MACRO

// Create and initialse array
int a[] = { 0, 1, 2, 3, 4 };
int main()
{
	int i;
	int* p;
	for (i = 0; i <= 4; i++) PRD(a[i]); // 1; Here we are using indexation to acesss the first 5 elements of array a(Calling the PRD with a[i] as the argument); Aka indexes(0-4); As a result this should output: 0,1,2,3,4 in this order
	NL;
	for (p = &a[0]; p <= &a[4]; p++) PRD(*p); // 2; Similar to the first statement except that here we are using pointers; Here p which is an int pointer starts by pointing at the first element in array a and proceeds by looking at each subsequent element in array a for each succesful iteration of the loop; As a result the output should be the same as the first: 0,1,2,3,4 in this order
	NL;
	NL;
	for (p = &a[0], i = 0; i <= 4; i++) PRD(p[i]); // 3; Here p points to the first element in array a; the for loop is executed as long as i is less than or equal to 4 so 5 iterations will be performed(0-4); We are printing out the elements in array a with the use of the index operator on a pointer which is allowed; With all of this in mind the output should be: 0,1,2,3,4 in this order
	NL;
	for (p = a, i = 0; p + i <= a + 4; p++, i++) PRD(*(p + i));//The idea is that we move p the pointer as well as i at once //(p + i) aka p pointer pushed out i positions is further away than a aka pointer pointing to the first element of array a pushed 4 positions; Then it's greater than a + 4); 4; p = a; a which is an array automatically converts to a pointer which points to the first element of the array; By setting this equal to p; Pointer p now points to the first element in array a(index 0); Hence this should print out: 0,2,4
	NL; //The last iteration for the above loo pis when p points to the second element of the array and i is 2 so p is shifted 2 positions/elements forward and so essentially now p points at the last element of array a; We also print out the value of this element as per the dererfrence when calling the MACRO
	NL; //We made this macro above; By calling this Macro we are essentially making a new line which is the body/contents of the Macro
	for (p = a + 4; p >= a; p--) PRD(*p); // 5; Here, p is a pointer that points at the last element in array(5th index). As long as p >= so essentially p is further away than pointer a we execute the loop and we decrement pointer p so that p makes it's way from the last element in array a to the first element; Therefore, this sould print out: 4,3,2,1,0
	NL;										//Comparing pointer ex: p <= a; Compares their position so is p is 4 positions out aka + 4 and a is 6 positions out aka + 6 then a is greater than p and this would yield in true; However if we had something like: 
	for (p = a + 4, i = 0; i <= 4; i++) PRD(p[-i]); // 6; Similar idea to above except that here we are using indexation -0; refers to the last element; -1 reffers to second to last element etc. We will be printing out the elements until we reach the first element; And so this should print out: 4,3,2,1,0
	NL;
	for (p = a + 4; p >= a; p--) PRD(a[p - a]); // 7; p is equal to pointer a which points to the first element in array a pushed 4 positions/elements forward so essentially p points at the last element of array a; Comparing pointer p with pointer a; As long as pointer p is farther away from pointer a it's greater; p - a = #of positions between these pointers by doing p-- we are moving pointer p from back to front and ultimately decreasing the distance between pointer p and pointer a; This will be done until both pointers will point at the first element aka difference will be 0 this will be our index to fetch the first element aka 0 index of array a; And so this should print out: 4,3,2,1,0
	NL;

	return 0;
}