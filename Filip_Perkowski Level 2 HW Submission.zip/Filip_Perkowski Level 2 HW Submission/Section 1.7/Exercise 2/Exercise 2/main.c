
/* Calculate the length of a string */
//In C, a string is an array of characters; This is because there is no string type in C
#include <stdio.h>
#define MAXLINE 30

// String lenght declaration
int Length(char str[]);
int main()
{
	char string[MAXLINE + 1]; // Line of maxium 30 chars + \0
	int c; // The input character
	int i = 0; // The counter
	// Print intro text
	printf("Type up to %d chars. Exit with ^Z\n", MAXLINE);
	// Get the characters
	while ((c = getchar()) != EOF && i < MAXLINE)
	{
		// Append entered character to string
		string[i++] = (char)c;
	}
	string[i] = '\0'; // String must be closed with \0
	printf("String length is %d\n", Length(string));
	return 0;
}

/* Implementing the Length() fuction */
//Below is the definition of our Length() function;
//Objective- The Length() function should simply use some sort of loop(while preffered since we don't know the number of iterations) to efficiently count the number of characters provided from user input

int Length(char str[]) {
	
	int cnt = 0; //This will be our counter variable which will hold the count aka number of characters inputted so far at the end hold the number of characters inputted by the user
	int mover = 0; //This variable will be used to move from one character to the next; I will assess this character through if statements
	
	while (str[mover] != '\0') { //If we have a null character then we want to terminate the loop and end our count; Fetching the elements by using an index[] operator
		if (str[mover] == '\n') { //This is to make it so that spaces for new lines do not count as characters
			cnt--;
		}
		cnt++;                   //We could've also done (*str) != '\0' and then done str++; so essentially moved the pointer; Remember that in C an array automatically converts itself to a pointer pointing to the first element in that array
		mover++;
	}
	
	return cnt;
	
}