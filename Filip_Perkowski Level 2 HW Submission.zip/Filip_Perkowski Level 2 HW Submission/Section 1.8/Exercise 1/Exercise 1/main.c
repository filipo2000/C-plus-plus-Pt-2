
#include <stdio.h>

//Objective- In this program I will be making a struct(a structure similar to a class) called Article; 
//As well as a function called Print() which will take in a struct object as a parameter

//Decleration of the Print() function
void Print(struct Article* z);//Our function will print out the contents of our struct object inputed as an argument whenever calling the function. Because we need a valid struct object for the function to work the functions parameter should be a pointer pointing to a struct object or a struct type parameter and a pass by value

//It's important to know that structures/structs can't hold functions
struct Article {
	//Within the Struct we have the Structs features/variables;
	//The contents must be assigned at initializtion level so let's do so
	//We can't initialize the members here our only ability is by creating an object of struct Article type and initializing the members there
	int ArticleNumber;
	int Quantity;
	const char* Description;

};



int main() {

	//If we wanted to incorporate user input then we would do so by making 3 different variables:
	//Using printf() and scanf_s() to get the fetch the inputs
	//We would lastly put them as initializers when we would decide to create an object of Article struct type
	
	
    //We will start off by making an struct Article object;
	struct Article obj = {10, 25, "Ferrari vs Lambo"};
    
	//1st Possible Function Call: Print(&obj); Adress of obj; This makes it so that z the pointer parameter points at obj
	//2nd Possible Function Call: Print(p); The argument as always is the value of the parameter for the function so in this case: z = p; So essentially by doing this z gets the same value as p; Aka z points to the same object p is pointing
	//If p we to point to a different object this wouldn't affect z;
	
	Print(&obj); //Appropriate function call to function Print(); Argument is the adress of a struct object as requested

}


//Here we will define our Print() function
void Print(struct Article* z) { //Function has a void return type as it does return anything
	printf("The Articles Number is: %d\n", z->ArticleNumber);
	printf("The Articles Quantity is: %d\n", z->Quantity);
	printf("The Articles Description is: %s\n", z->Description);
}